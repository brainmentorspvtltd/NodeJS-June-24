 export async function getProducts(){
    const URL = 'https://fakestoreapi.com/products';
    try{
    const response = await fetch(URL);
    const products = await response.json();
    return products;
    }
    catch(err){
        throw err; 
    }
}

// export function show(){

// }
// export function disp(){

// }


//export default getProducts;