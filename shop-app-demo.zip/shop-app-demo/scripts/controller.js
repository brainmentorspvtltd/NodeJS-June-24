import {getProducts} from './api-client.js';
async function loadProducts(){
    const products = await getProducts();
    products.forEach(printProduct);
}
loadProducts();

function printProduct(singleProduct){
    const div = document.createElement('div'); // <div/>
    const image = document.createElement('img'); // <img/>
    image.src = singleProduct.image;
    image.className = 'size';
    const p = document.createElement('p');
    p.innerText = singleProduct.title + " "+singleProduct.price;
    div.appendChild(image);
    div.appendChild(p);
    document.querySelector('#result').appendChild(div);
}

