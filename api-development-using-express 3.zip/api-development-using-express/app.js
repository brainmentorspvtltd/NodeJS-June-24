import express from 'express';
import chalk from 'chalk';
import dotenv from 'dotenv';
import favicon from 'serve-favicon';
import { getStaticContentPath } from './shared/utils/relative-path.js';
import { userRoutes } from './modules/users/routes/user-routes.js';
import { error404MiddleWare } from './shared/middlewares/404.js';
const app = express();
dotenv.config();
// express - all about middlewares

app.use(favicon(getStaticContentPath(import.meta.url,'favicon.png')));
app.use(express.static('public')); // Static File Serve
// request body data read - middleware
app.use(express.json());
// Dynamic Things
app.use('/',userRoutes);

// Last Middleware
app.use(error404MiddleWare);

//app.use(favicon(path.join(__dirname)))
//app.use(favicon('/Users/amitsrivastava/Documents/api-development-using-express/public/favicon.ico'));
console.log('DB Name ', process.argv[2], 'DB Port No', process.argv[3], 'Env ', process.argv[4]);
const server = app.listen(process.env.PORT||3333, err=>{
    if(err){
        console.log(chalk.redBright.bold('Application Crash '), err);
    }
    else{
        console.log(chalk.greenBright.bold('Application Up and running.... '), server.address().port);
    }
})