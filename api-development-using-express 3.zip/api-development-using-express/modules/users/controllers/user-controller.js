import { userService } from "../services/user-services.js";

export const login = async (request, response)=>{
    //response.json({'message':'User Login'});
    const customerData = request.body;
    const result = await userService.login(customerData);
    response.json(result);
}
export const register = async (request, response)=>{
    console.log('Register Controller');
    const customerData = request.body;
    const result = await userService.register(customerData);
    console.log('Request Data Rec in Register ', customerData);
    //response.json({'message':'User Register'});
    response.json(result);
}

export const viewAllUsers = (request, response)=>{
    response.json({'message':'View All Users'});
}