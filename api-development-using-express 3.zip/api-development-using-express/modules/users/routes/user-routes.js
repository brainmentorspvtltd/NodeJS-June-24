import express from 'express';
import { login, register, viewAllUsers } from '../controllers/user-controller.js';
import { APP_CONSTANTS } from '../../../shared/utils/app-constants.js';
import { validate } from '../../../shared/middlewares/schema-validation.js';
import { userSchema } from '../validations/user-schema.js';
const {LOGIN, REGISTER, VIEW_ALL_USERS} = APP_CONSTANTS.ROUTES.USER_ROUTES;
export const userRoutes = express.Router();
userRoutes.post(LOGIN, login );
//userRoutes.post(URL, middleware, controllerFn)
userRoutes.post(REGISTER, register);
//userRoutes.post(REGISTER, validate(userSchema) ,register);
userRoutes.get(VIEW_ALL_USERS, viewAllUsers)

