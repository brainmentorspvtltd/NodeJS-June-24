import sql from 'mssql';
import { sqlConfig } from './db-config.js';
export async function connection(){
    try{
    await sql.connect(sqlConfig);
    console.log('Connection Establish')
    }
    catch(err){
        console.log('DB Connection Fail ', err);
        throw err;
    }
}
connection();