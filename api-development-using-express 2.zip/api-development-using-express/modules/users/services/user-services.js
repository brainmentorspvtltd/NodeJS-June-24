// DB CRUD Operations
export const userService= {
    login(userData){

    },
    register(userData){

    },
    viewAllUsers(){

    },
    viewOneUser(userData){

    }
}