export const login = (request, response)=>{
    response.json({'message':'User Login'});
}
export const register = (request, response)=>{
    console.log('Register Controller');
    const body = request.body;
    console.log('Request Data Rec in Register ', body);
    response.json({'message':'User Register'});
}

export const viewAllUsers = (request, response)=>{
    response.json({'message':'View All Users'});
}