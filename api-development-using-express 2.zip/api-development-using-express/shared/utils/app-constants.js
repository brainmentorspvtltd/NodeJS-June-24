export const APP_CONSTANTS = {
    ROUTES:{
        USER_ROUTES:{
            LOGIN:'/login',
            REGISTER:'/register',
            VIEW_ALL_USERS : '/view-all-users'
        }
    }
}