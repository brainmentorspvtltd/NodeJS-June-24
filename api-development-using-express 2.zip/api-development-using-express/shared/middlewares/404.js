
export const error404MiddleWare = (request, response, next)=>{
    response.status(404).json({message:'Resource Not Found'});
}