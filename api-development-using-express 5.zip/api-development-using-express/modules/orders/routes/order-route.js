import express from 'express';
import { callThirdPartyAPI } from '../../../shared/utils/api-client.js';
export const orderroutes = express.Router();
orderroutes.get('/orders', (req, res)=>{
    res.json({"orders":"All Orders"});
})

orderroutes.get('/products', async(req, res)=>{
    const response = await callThirdPartyAPI('GET', 'https://fakestoreapi.com/products');
    res.json({"result":response.data});
})