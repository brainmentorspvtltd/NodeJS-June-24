import { messageBundle } from "../../../shared/i18n/en.js";
import { loggerFn } from "../../../shared/utils/app-logger.js";
import ErrorHandler from "../../../shared/utils/error-handler.js";
import { callSoapAPI } from "../../../shared/utils/soap-client.js";
import { userService } from "../services/user-services.js";

export const login = async (request, response, next)=>{
    const logger = loggerFn('user-controller.js');
    //response.json({'message':'User Login'});
    const customerData = request.body;
    if(10>2){
     //   next( new ErrorHandler('Some Issue Login',500, new Error('Login Error')));
    }
    logger.debug('Customer Data '+customerData);
    const result = await userService.login(customerData);
    logger.debug('Customer Login Done '+result);
   
    response.json(result);
}
export const register = async (request, response)=>{
    const logger = loggerFn('user-controller.js');
    console.log('Register Controller');
    const customerData = request.body;
    const result = await userService.register(customerData);
    console.log('Request Data Rec in Register ', customerData);
    //response.json({'message':'User Register'});
    response.json(result);
}

export const viewAllUsers = async (request, response)=>{
    const logger = loggerFn('user-controller.js');
    const result = await userService.viewAllUsers();
    response.json(result);
}

export const viewUser =(request, response)=>{
    const logger = loggerFn('user-controller.js');
    // get the path parameter
    const obj  = request.params;
    response.status(200).json({"msg":messageBundle['user.greet.msg'] + obj.username + " "+obj.phone});
}

export const dispUser =(request, response)=>{
    // get the path parameter
    const obj  = request.query;
    console.log('Query Param ', obj);
    response.json({"Query Param ":obj.email + " "+obj.city, "image":"x.jpg"});
}

export const callSOAPBASEAPI = (req, res)=>{
    const data = {id:1001, name:'Ram'};
    callSoapAPI('https://www.dataaccess.com/webservicesserver/numberconversion.wso?WSDL', data);
    res.json({message:'SOAP API CALL'});
}
