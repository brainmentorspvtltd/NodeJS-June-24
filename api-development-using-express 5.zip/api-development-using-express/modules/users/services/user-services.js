// DB CRUD Operations
import { connection } from "../../../shared/db/connection.js";
import sql from 'mssql';
import { compareHash, passwordHashing } from "../../../shared/utils/password-hash.js";
import { generateToken } from "../../../shared/utils/token.js";
import { loggerFn } from "../../../shared/utils/app-logger.js";
import ErrorHandler from "../../../shared/utils/error-handler.js";

export const userService= {
    async login(userData){
        const logger = loggerFn('user-services.js');
        logger.debug("Inside Service "+JSON.stringify(userData));
        const inputRequest = new sql.Request();
        inputRequest
        .input("email", sql.VarChar(50), userData.email)
        .input("pwd", sql.VarChar(200), userData.password);
        try{
            const result = await inputRequest.query('select email, name, city, password from customers where email=@email');
            if(result && result.recordset && result.recordset.length>0){
                console.log('RecordSet ' , result.recordset, ' Plain ', userData.password);
                const dbPwd = result.recordset[0].password;
                if(compareHash(userData.password, dbPwd)){
                    const token = generateToken(userData);
                    return {"message":"Customer Login SuccessFully ", result: result, token:token};   
                }
                else{
                    return {"message":"Customer Login Fails  ", result: result}; 
                }
                
           
            }
            else{
                return {"message":"Customer Login Fails  ", result: result};   
            }
           }
           catch(err){
            logger.error("Error is "+JSON.stringify(err));
               throw err;
           }
    },
    async register(userData){
        const logger = loggerFn('user-services.js');
        const inputRequest = new sql.Request();
        inputRequest
        .input("id", sql.Int, userData.id)
        .input("name", sql.VarChar(50), userData.name)
        .input("email", sql.VarChar(50), userData.email)
        .input("password", sql.VarChar(200), passwordHashing( userData.password))
        .input("city", sql.VarChar(50), userData.city);
        try{
         const result = await inputRequest.query('insert into Customers (customerid, name, email, password, city) values(@id, @name, @email, @password, @city)');
         return {"message":"Customer Register SuccessFully ", result: result};   
        }
        catch(err){
            
            throw new ErrorHandler('Error During Register', 500, err);
        }
        // insert into table (cols) values(?,?,?)
    },
    async viewAllUsers(){
        const inputRequest = new sql.Request();
        const result = await inputRequest.query('select email, name, city from customers ');
        return {"message":"Customer All Data ", result: result};   
    },
    async viewAllUsersPagination(limit, offset){
        const inputRequest = new sql.Request();
        const result = await inputRequest.query(`select email, name, city from customers  LIMIT ${limit} OFFSET ${offset}`);
        return {"message":"Customer All Data ", result: result};   
    },
    viewOneUser(userData){

    }
}