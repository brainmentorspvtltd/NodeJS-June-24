export const messageBundle = {
    "user.greet.msg":"Welcome User... ",
    "user.login.fails":"Login Fail"
}