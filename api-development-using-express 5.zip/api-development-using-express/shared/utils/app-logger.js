import winston from 'winston';
const {timestamp, label, combine, printf, colorize}= winston.format;
const customFormat = printf(({level, message,label, timestamp})=>{
    return `${timestamp} [${label}] ${level}: ${message}`;
});

export const loggerFn = (moduleName)=>{
    console.log('ENV ', process.env.APP_ERROR_LOGS, process.env.APP_COMMON_LOGS)
    return  winston.createLogger({
        level:'debug',
        format: combine(
            label({ label: moduleName }),
            timestamp(),
            customFormat,
            colorize()
          ),
        //format:winston.format.json(),
        transports: [
            //
            // - Write all logs with level `error` and below to `error.log`
            // - Write all logs with level `info` and below to `combined.log`
            //
            new winston.transports.File({
                filename: process.env.APP_ERROR_LOGS,
                 level: 'error',
                 colorize:true,
                  maxsize: 20971520, // 20 MB
                  maxFiles:5

                 }),
            new winston.transports.File({
                filename: process.env.APP_COMMON_LOGS,
                 colorize:true ,
                 maxsize: 20971520, // 20 MB
                 maxFiles:5
                }),
          ]
    });
}