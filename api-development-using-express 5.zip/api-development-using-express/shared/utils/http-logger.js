import fs from 'fs';
export const getStream = ()=>{
    console.log('Stream ', process.env.HTTP_LOGS);
const stream =  fs.createWriteStream(process.env.HTTP_LOGS, {
    interval: '7d' // rotate weekly

  });
  return stream;
}
