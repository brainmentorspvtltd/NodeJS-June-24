import axios from 'axios';
export const callThirdPartyAPI = async (method, URL , data)=>{
    const response = await axios({
        method: method,
        url: URL,
        data: data});
        return response;
}