import soap from 'soap';
export const callSoapAPI = (URL, data)=>{
    //var args = {name: 'value'};

  soap.createClient(URL, {}, function(err, client) {
    if (err) {
        console.error("An error has occurred creating SOAP client: " , err);  
    } else {
        // Log a description of the services the server offers.
        var description = client.describe();
        console.log("Client description:" , description);
        // Go on and call the method.
        var method = client['NumberToWords'];
        method({ubiNum:1234}, function(err, result, envelope, soapHeader) {
            console.log('Response Envelope: \n' + envelope);
            console.log('Result: \n' + JSON.stringify(result));
        });
    }
  

})
}