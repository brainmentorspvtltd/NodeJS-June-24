import bcrypt from 'bcrypt';
const SALT =10;
export const passwordHashing = (plainPassword)=>{
    return bcrypt.hashSync(plainPassword, SALT);
}
export const compareHash = (plainPassword, encryptPwd)=>{
    return bcrypt.compareSync(plainPassword, encryptPwd);
}