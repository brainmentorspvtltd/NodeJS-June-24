import jwt from "jsonwebtoken";
const SECRET_KEY = 'UCANTSEEME';
export const generateToken = (payload)=>{
    return jwt.sign({'email':payload.email}, SECRET_KEY, { expiresIn: '1h' });
}
export const verifyToken =(token)=>{
    try{
    return jwt.verify(token, SECRET_KEY);
    }
    catch(err){
        throw err;
    }
}