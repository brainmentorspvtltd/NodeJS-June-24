export const APP_CONSTANTS = {
    HTTP_STATUS_CODES : {
        SUCCESS : 200
    },
    ROUTES:{
        USER_ROUTES:{
            LOGIN:'/login',
            REGISTER:'/register',
            VIEW_ALL_USERS : '/view-all-users'
        }
    }
}