import path from 'path';
import { dirname } from 'path';
import { fileURLToPath } from 'url';
export const getStaticContentPath = (basepath, fileName)=>{
const __dirname = dirname(fileURLToPath(basepath));
const fullPath = path.join(__dirname, 'public', fileName);
//console.log(fullPath);
return fullPath;

}