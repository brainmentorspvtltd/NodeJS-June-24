class ErrorHandler extends Error {
    constructor(message, statusCode, err) {
      super(message);
      this.statusCode = statusCode;
      this.err = err;
    }
  }
  
  export default ErrorHandler;