import Joi from "joi"

 
export const validate = (schema)=>{
    return (request, response, next)=>{
        const data = request.body ;
    
    const {error} = schema.validate(data);
    //console.log('Validation Result Middleware ', error.details);
    if(error && error.details){
        response.json({message:error.details});
    }
    else{
    next(); // Move to the Next Middleware
    }
    }
}