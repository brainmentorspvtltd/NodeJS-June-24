import { verifyToken } from "../utils/token.js"

export const tokenMiddleWare = (request, response, next)=>{
    const token = request.headers['authorization'];
    console.log('Token ', token);
    try{
    const decoded = verifyToken(token);
    if(decoded && decoded.email){
        next();
    }
    else{
        response.status(401).json({"message":"User Not Having Token"});
    }
}
catch(err){
    response.status(401).json({"message":"User Not Having Token"});
}
}