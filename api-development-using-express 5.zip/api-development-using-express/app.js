import express from 'express';
import chalk from 'chalk';
import dotenv from 'dotenv';
import favicon from 'serve-favicon';
import { getStaticContentPath } from './shared/utils/relative-path.js';
import { userRoutes } from './modules/users/routes/user-routes.js';
import { error404MiddleWare } from './shared/middlewares/404.js';
import { connection } from './shared/db/connection.js';
import { tokenMiddleWare } from './shared/middlewares/token-middleware.js';
import { orderroutes } from './modules/orders/routes/order-route.js';
import morgan from 'morgan';
import { getStream } from './shared/utils/http-logger.js';
import { loggerFn } from './shared/utils/app-logger.js';
import cors from 'cors';
import { errorHandler } from './shared/middlewares/error-middleware.js';
process.on('uncaughtException', err=>{
    console.log('uncaughtException ', err);
})
const app = express();
dotenv.config();
const logger = loggerFn('app.js');
app.use(cors( {
    origin: 'http://10.1.90.20'}));
    
// express - all about middlewares
app.use(morgan('combined',{stream : getStream()}));
app.use(favicon(getStaticContentPath(import.meta.url,'favicon.png')));
app.use(express.static('public')); // Static File Serve
// request body data read - middleware
app.use(express.json());
// Dynamic Things
app.use('/',userRoutes); // Login, Register
// Verify token
app.use(tokenMiddleWare);
app.use('/api/v5',orderroutes);
// Last Middleware
app.use(errorHandler);
app.use(error404MiddleWare);

//app.use(favicon(path.join(__dirname)))
//app.use(favicon('/Users/amitsrivastava/Documents/api-development-using-express/public/favicon.ico'));
//console.log('DB Name ', process.argv[2], 'DB Port No', process.argv[3], 'Env ', process.argv[4]);
const promise = connection();
promise.then(data =>{
    console.log(chalk.greenBright.bold('DB Connection Establish '));
    const server = app.listen(process.env.PORT||3333, err=>{
        if(err){
            console.log(chalk.redBright.bold('Application Crash '), err);
        }
        else{
            console.log(chalk.greenBright.bold('Application Up and running.... '), server.address().port);
        }
    })

}).catch(err=>{
    logger.error(err);
    console.log(chalk.red.bold('DB Connection Fails... '), err);
})
